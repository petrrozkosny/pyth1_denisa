import datetime
from pathlib import Path
import requests
from faker import Faker

# Funkce vypisujici aktualni datum a cas

def vypis_cas():
    print(datetime.datetime.now())


def pozdrav_uzivatele(uzivatel):
    print(f'Ahoj uzivateli {uzivatel}')

def spocitej_soubory():
    aktualni_slozka = Path.cwd()
    py_soubory = aktualni_slozka.rglob('*.py')
    py_soubory = list(py_soubory)
    print(f'Pocet .py souboru ve slozce {len(py_soubory)}')


# Libovolny pocet pojmenovanych parametru, kdy nazvem parametru bude jmeno uzivatele a hodnotou bude
# programovaci jazyk

def uzivatel_jazyk(**kwargs):
    for i,j in kwargs.items():
        print(f'{i} umi {j}')

'''
1. V uzivatelske_funkce.py vytvorte funkci wiki
2. Tato funkce bude mit jeden pozicni argument stranka
3. Uvnitr funkce definujte promennou wiki s hodnotou https://cs.wikipedia.org/wiki/
4. Do promenne obsah si ulozte vysledek requests.get() zavolejte wiki+stranka
5. Do promenne status si ulozte obsah.status_code
6. Pokud status != 200 vypiste "Stranka neexistuje", jinak vypiste "stranka existuje"
'''


def zkontroluj_wiki(stranka):
    wiki = 'https://cs.wikipedia.org/wiki/'
    obsah = requests.get(wiki+stranka)
    status = obsah.status_code
    if status != 200:
        print('Stranka neexistuje')
    else:
        print('Stranka existuje')


'''
1. Do uzivatelske_funkce.py naimportujte knihovnu random
2. Vytvorte funkci hadej_cislo() s jednim pozicnim argumentem cislo
3. Ve funkci si vytvorte promennou nahodne_cislo = random.randint(1,3)
4. Zkuste cislo prevest na int, pokud se to nepodari z duvodu ValueError, vratte "Nelze prevest na cislo"
5. Pokud cislo neni 1-3 (napr. uzivatel zada 10), vypiste uzivateli "Cislo mimo rozsah 1-3"
6. Pokud cislo je v rozsahu 1-3 a rovna se nahodne_cislo, vratte "Uhádnul jsi", jinak vraťte "Neuhádnul jsi"

'''
import random
def hadej_cislo(cislo):
    try:
        cislo = int(cislo)
    except ValueError:
        print('Nelze prevest na cislo')
    else:
        if cislo >= 1 and cislo <=3:
            nahodne_cislo  = random.randint(1,3)
            if cislo == nahodne_cislo:
                print('Uhadnul jsi')
            else:
                print('Neuhadnul jsi')
        else:
            print('Cislo mimo rozsah 1-3')


'''
Cvičení 3 (první část)

uzivatelske_funkce.py
1. Naimportujte: from faker import Faker
2. Vytvořte funkci generuj_email(), která nemá žádné argumenty
3. Do proměnné mail si uložte výsledek Faker().email()
4. Vraťte uživateli přes return hodnotu proměnné mail

main.py
5. Zkuste zavolat funkci generuj_email(), návratovou hodnotu si uložte do fake_email
'''

def generuj_email():
    mail = Faker().email()
    return mail

def vypis_neco():
    print(__name__)

if __name__ == '__main__':
    vypis_neco()