import uzivatelske_funkce
import requests

uzivatelske_funkce.vypis_neco()
exit()

uzivatelske_funkce.vypis_cas()
uzivatelske_funkce.pozdrav_uzivatele('Honza')
uzivatelske_funkce.spocitej_soubory()
uzivatelske_funkce.uzivatel_jazyk(honza='Python',ivo='Java',kuba = None)




'''
7. V main.py vytvorte list stranky s hodnotami = 'Praha','ictpro','python'
8. Prochazejte stranky a opakovane volejte funkci z bodu 1-6
'''

stranky = ['Praha','ictpro','python']
for i in stranky:
    uzivatelske_funkce.zkontroluj_wiki(i)


uzivatelske_funkce.hadej_cislo('deset')

fake_email = uzivatelske_funkce.generuj_email()
print(fake_email)


fake_emaily = []
i = 0

while i < 100:
    # alternativne for i in range(100):
    fake_email = uzivatelske_funkce.generuj_email()
    fake_emaily.append(fake_email)
    i += 1
    # i = i+1
vstup = input('Zadej email: ')
if '@' in vstup:
    if vstup in fake_emaily:
        print('Email existuje')
    else:
        print('Email neexistuje')
else:
    print('Neplatna emailova adresa')