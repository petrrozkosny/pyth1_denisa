class Bojovnik:
    def __init__(self, jmeno, zbran):
        self.__jmeno = jmeno  # Atribut není snadno přístupný
        self.zbran = zbran

bojovnik = Bojovnik("Rumcajs", "mec")
# Tento pokus o přístup selže
# print(bojovnik.__jmeno)  # Chyba: AttributError

# Ale interně Python atribut přejmenoval na _Bojovnik__jmeno, takže ho lze stále získat
print(bojovnik._Bojovnik__jmeno)  # Výstup: Rumcajs
