

# parent class
class Postavicka:
    def __init__(self,jmeno):
        self.jmeno = jmeno
        print('jsem v init parent')
# child class
class Bojovnik(Postavicka):
    # promenna / atribut tridy
    rajon = 'Ceska republika'
    pocet_bojovniku = 0

    def __init__(self,zbran,jmeno):
        self.zbran = zbran
        Bojovnik.pocet_bojovniku += 1
        # vola konstruktor parent class, tj. Postavicka      
        super().__init__(jmeno)
        print('jsem v init')

    # metoda tridy
    @classmethod
    def vypis_pocet_bojovniku(cls):
        print(f'Aktuální počet bojovníků {cls.pocet_bojovniku}')

    # metoda instance
    def vyhrozuj(self):
        print(f'Jmenuji se {self.jmeno}, davej si na me pozor')

    @staticmethod
    def vypis_zbran():
        
        print('Ukoncuji')

    @staticmethod
    def potvrd_vytvoreni():
        print('Potvrzuji')

    @staticmethod
    def ukonci():
        print('ukoncuji')

    def __str__(self):
        return f'Jsem instance {self.jmeno}, mam zbran {self.zbran}'


print('pristupuji k vytvoreni loupeznika')
loupeznik1 = Bojovnik('mec','Rumcajs')
Bojovnik.vypis_pocet_bojovniku()
loupeznik2 = Bojovnik('zaludovka','Cipisek')
Bojovnik.vypis_pocet_bojovniku()
print(loupeznik1.jmeno)
print(loupeznik1.rajon)
print(loupeznik2.rajon)

loupeznik1.potvrd_vytvoreni()
loupeznik1.ukonci()
print(loupeznik1)
print(loupeznik1.__dict__)

Bojovnik.rajon = 'Řáholec'

print(loupeznik1.rajon)
loupeznik1.jmeno =  'Rozkosny'

print(loupeznik1.jmeno)
