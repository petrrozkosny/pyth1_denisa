


# Napište funkci, která kontotroluje, jestli číslo je menší než 10. Pokud ano, tiskneme "Ano", jinak "Ne"

def zkontroluj_cislo(cislo):
    if cislo < 10:
        print('Ano')
    else:
        print('Ne')

zkontroluj_cislo(5)
zkontroluj_cislo(11)


# Napiste funkci pozdrav s pozicnim parametr uzivatel a pojemnovanym parametrem cast_dne
# Pokud neni dosazena hodnota parametru cast_dne, vypiste "Dobrý den {uzivatel}", jinak vypiste Dobrý {cast_dne} {uzivatel}

def pozdrav(uzivatel,cast_dne = None):
    if cast_dne is None:
        print(f'Dobrý den {uzivatel}')
    else:
        print(f'Dobrý {cast_dne} {uzivatel}')

pozdrav('Ivo')
pozdrav('Honza', 'večer')

def pozdrav2(*,uzivatel=None,mesto=None):

    if uzivatel is None or mesto is None:
        print('Dobrý den')
    else:
        print(f'{uzivatel} vitej v {mesto}')

pozdrav2(mesto='Praha',uzivatel='Kuba')



def pozdrav3(mesto,uzivatel=None):
    print('Ahoj')

def vydel(cislo1:int, cislo2:int) -> int:
    vysledek = int(cislo1/cislo2)
    return vysledek
    

#vysledek_deleni = vydel("deset",2)
#print(f'Výsledke po dělení je {vysledek_deleni}')
#vydel()

def vynasob_dvema(cislo: int) -> int:
    vysledek = cislo * 2
    return vysledek


vysledek = vynasob_dvema(2)
print(vysledek)


def vynasob_dvema_dynamicke(*args):
   for i in args:
       print(f'vysledek je {i * 2}')


vynasob_dvema_dynamicke(2,10,20,12,5,6,7,89,351384,687468)




