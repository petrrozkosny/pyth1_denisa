mesta = ['Praha','Brno','Ostrava']
vstup = input('Zadejte pozici mesta v listu: ')

try:
    vstup = int(vstup)
    try:
        print(f'Mesto na pozici {vstup} je {mesta[vstup]}')
    except IndexError:
        print(f'Na zadane pozici neni zadne mesto')
except ValueError:
    print('Zadana hodnota neni platnym cislem')
