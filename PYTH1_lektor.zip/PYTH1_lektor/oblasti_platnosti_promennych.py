# from pathlib import Path

# soubor_existuje = False
# nazivu = True


# def zkontroluj_soubor():
#     cwd = Path.cwd()
#     soubory = list(cwd.rglob('funkce.py'))
#     if soubory == []:
#        pass
#     else:
#         global soubor_existuje
#         soubor_existuje = True



#     global soubor_existuje
#     soubor_existuje = True

# __name__ = '__main__'
print(__name__)  

