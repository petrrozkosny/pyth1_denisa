zeme_info = {
    1: {
        "zeme": "Cesko",
        "mesta": ["Praha", "Brno", "Ostrava"],
        "reky": ["Vltava", "Labe", "Morava"]
    },
    2: {
        "zeme": "Rakousko",
        "mesta": ["Vídeň", "Graz", "Linz"],
        "reky": ["Dunaj", "Inn", "Mur"]
    },
    3: {
        "zeme": "Slovensko",
        "mesta": ["Bratislava", "Košice", "Prešov"],
        "reky": ["Dunaj", "Váh", "Hron"]
    },
    4: {
        "zeme": "Madarsko",
        "mesta": ["Budapešť", "Debrecín", "Szeged"],
        "reky": ["Dunaj", "Tisa", "Rába"]
    }
}
seznam_zemi = []
for k,v in zeme_info.items():
    zeme = v['zeme']
    seznam_zemi.append(zeme)

zeme_text = str(zeme_info.values())

mesta_retezec = 'Praha Brno Ostrava'
mesta_list = mesta_retezec.split(' ')
mesta_retezec2 = ', '.join(mesta_list)


neexistujici_zeme = []
'''
Cviceni1
Do promenne vstup si ulozit nazev zeme, na kterou se chcete zeptat
Pokud zeme neni v zeme_info, vypiseme, ze zeme neni v seznamu a pridame ji do listu neexistujici_zeme
'''

vstup = input('Zadej nazev zeme: ')
hodnoty = zeme_info.values()
#existuje = False
existuje = False
for k in hodnoty:
    zeme = k['zeme']
    if zeme == vstup:
        print('Zeme existuje')
        existuje = True
        break


if existuje == False:
    print('Zeme neexistuje')
    neexistujici_zeme.append(vstup)

        



  

'''
Cviceni2
Do promenne vstup_zeme si ulozte nazev zeme, kterou chce uzivatel pridat do slovniku
Pokud nazev zeme ve slovniku je, vratte uzivateli "Zeme uz ve slovniku je", jinak 
pridejte zemi do slovniku a vypiste "Zeme pridana".
Hodnoty klicu mesta a reky budou prazdne listy
'''



vstup = input ('Zadej nazev zeme: ')
hodnoty = zeme_info.values()

existuje = False

for k in hodnoty:
    zeme = k['zeme']
    if zeme == vstup:
        print('Zeme existuje')
        existuje = True
        break
   
if existuje == False:
    pocet_klicu = len(zeme_info.keys())+1
    zeme_info[pocet_klicu] = {'zeme': vstup, 'mesta': [], 'reky': []}
print(zeme_info)


'''
Cviceni3
Do promenne vstup_cislo zeme si ulozte poradi (idnex) zeme, na kterou se uzivatel chce zeptat
Pokud zeme s timto indexem neexistuje, vypiste, ze zeme neexistuje
Pokud vstup uzivatele neni mozne prevest na cistlo, vypiste "Zadana hodnota neni cislo"
Pokud je mozne vstup prevest na cislo a zeme s danym indexem existuje, vypiste "Zeme existuje"
'''

vstup_cislo = input('Zadej cislo zeme: ')
try:
    vstup_cislo = int(vstup)
    if vstup_cislo in zeme_info.keys():
        print('Zeme existuje')
    else:
        print('Zeme neexistuje')
except ValueError:
    print('Zadana hodnota neni cislo')


mesta = ['Praha','Brno']

mesta = [i.lower() for i in mesta]
print(mesta)
