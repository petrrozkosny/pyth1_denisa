



ucastnici = ['Ivo','Honza',5,'Honza']

# Je tomas v ucastnicich?

print('Ivo' not in ucastnici)

print(['Ivo'] == ucastnici)