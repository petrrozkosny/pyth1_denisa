


def pozdrav(*,jmeno=None,mesto=None,den=None):
    print(f'Ahoj {jmeno} z {mesto} v {den}!')

#pozdrav(jmeno='Honzo',den='pondělí')


postavicka = {
    'jmeno':'Honza',
    'mesto':'Brno',
    'sila':20

}

print(postavicka['sila'])
postavicka['sila'] = postavicka['sila'] + 10
print(postavicka['sila'])
nova_sila = postavicka['sila'] 