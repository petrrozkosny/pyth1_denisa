import pandas as pd

# url = 'https://cs.wikipedia.org/wiki/Seznam_m%C4%9Bst_v_%C4%8Cesku_podle_po%C4%8Dtu_obyvatel'

# # nazev promenne 
# df = pd.read_html(url)[0]

# slovnik = df.to_dict()
# print(df['Rozloha (km²)'].max())

df = pd.read_csv('mesasdfadsfsadta.csv')
